# This is a bunch of hacks for school

## ⚠ Anything that you get in trouble for is not the creators fault ⚠
## Use this for good
